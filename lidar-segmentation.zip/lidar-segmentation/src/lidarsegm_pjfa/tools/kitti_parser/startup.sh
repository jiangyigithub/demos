rm -rf build
rm -rf out
mkdir build
mkdir out
cd build
cmake ..
make

