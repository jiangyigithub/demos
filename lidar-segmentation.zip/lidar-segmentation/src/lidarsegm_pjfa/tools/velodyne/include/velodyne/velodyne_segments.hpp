#ifndef VELODYNE_SEGMENTS_HPP_INCLUDED
#define VELODYNE_SEGMENTS_HPP_INCLUDED

#include "velodyne_segments_v1.hpp"

namespace velodyne
{

typedef VelodyneSegments_v1 VelodyneSegments;

}

#endif
