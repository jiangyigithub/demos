#ifndef VELODYNE_SCAN_HPP_INCLUDED
#define VELODYNE_SCAN_HPP_INCLUDED

#include "velodyne_scan_v1.hpp"

namespace common_daddy_interfaces
{

typedef VelodyneScan_v1 VelodyneScan;

}

#endif
