#ifndef VELODYNE_SCAN_IMAGE_HPP_INCLUDED
#define VELODYNE_SCAN_IMAGE_HPP_INCLUDED

#include "velodyne_scan_image_v1.hpp"

namespace common_daddy_interfaces
{

typedef VelodyneScanImage_v1 VelodyneScanImage;

}

#endif
